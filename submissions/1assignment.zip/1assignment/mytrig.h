#ifndef __mytrig_H_INCLUDED__
#define __mytrig_H_INCLUDED__

double mysin(double angle);
double mycos(double angle);
double mytan(double angle);

#endif
