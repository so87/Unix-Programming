#include "mytrig.h"
#include <cmath>

using namespace std;

double mycos(double angle)
{
		return mysin(angle+(3.1415926535/2.0));
}
